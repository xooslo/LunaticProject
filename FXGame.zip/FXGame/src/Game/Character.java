package Game;

import javafx.geometry.Rectangle2D;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class Character extends Pane {

	// Character Configuration
	ImageView imageView;
	int count = 3;
	int columns = 3;
	int offsetX = 30;
	int offsetY = 5;
	int width = 48;
	int height = 71;
	int score = 0;

	Rectangle removeRect = null;
	SpriteAnimation animation;

	public Character(ImageView imageView) {
		this.imageView = imageView;
		this.imageView.setViewport(new Rectangle2D(offsetX, offsetY, width, height));
		animation = new SpriteAnimation(imageView, Duration.millis(200), count, columns, offsetX, offsetY, width,
				height);
		getChildren().addAll(imageView);
	}

	public void moveX(int x) {
		boolean right = x > 0 ? true : false;
		for (int i = 0; i < Math.abs(x); i++) {
			if (right)
				this.setTranslateX(this.getTranslateX() + 1);
			else
				this.setTranslateX(this.getTranslateX() - 1);
			isBonus();
		}
	}

	public void moveY(int y) {
		boolean right = y > 0 ? true : false;
		for (int i = 0; i < Math.abs(y); i++) {
			if (right)
				this.setTranslateY(this.getTranslateY() + 1);
			else
				this.setTranslateY(this.getTranslateY() - 1);
			isBonus();
		}
	}
	
	public void isBonus() {
		Main.bonuses.forEach((rect) -> {
			if(this.getBoundsInParent().intersects(rect.getBoundsInParent())) {
				removeRect = rect;
				score++;
				++score;
				System.out.println(score); // If you want to add a label. Do it here ( and have it record your score on th app )
			}
		});
		Main.bonuses.remove(removeRect);
		Main.root.getChildren().remove(removeRect);
	}

}
