package Game;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Main extends Application {

	private HashMap<KeyCode, Boolean> keys = new HashMap<>();
	public static ArrayList<Rectangle> bonuses = new ArrayList<>();
	public static ArrayList<Circle> bonuses2 = new ArrayList<>();
	Image image = new Image(getClass().getResourceAsStream("darthvader.gif"));
	ImageView imageView = new ImageView(image);
	Character player = new Character(imageView);
	static Pane root = new Pane();

	public void bonus() {
		int random = (int) Math.floor(Math.random() * 100);
		int x = (int) Math.floor(Math.random() * 600);
		int y = (int) Math.floor(Math.random() * 600);
		if (random == 5) {
			Rectangle rect = new Rectangle(40, 40, Color.BROWN);
			rect.setX(x);
			rect.setY(y);
			bonuses.add(rect);
			root.getChildren().addAll(rect);
		}

		if (random == 4) {
			Circle circle = new Circle(50, Color.BLUE);
			circle.setCenterX(100);
			circle.setCenterY(100);
			circle.setRadius(50);
			bonuses2.add(circle);
			root.getChildren().addAll(circle);
		}
	}

	public void update() {
		if (isPressed(KeyCode.UP)) {
			player.animation.play();
			player.animation.setOffsetY(75);
			player.moveY(-2);
		} else if (isPressed(KeyCode.DOWN)) {
			player.animation.play();
			player.animation.setOffsetY(5);
			player.moveY(2);			
		} else if (isPressed(KeyCode.RIGHT)) {
			player.animation.play();
			player.animation.setOffsetY(146);
			player.moveX(2);			
		} else if (isPressed(KeyCode.LEFT)) {
			player.animation.play();
			player.animation.setOffsetY(146);
			player.moveX(-2);			
		} else {
			player.animation.stop();
		}
	}
	
	public boolean isPressed(KeyCode key) {
		return keys.getOrDefault(key, false);
	}

	@Override
	public void start(Stage primaryStage) {
		try {
			root.setPrefSize(600, 600);
			root.getChildren().addAll(player);
			
			Scene scene = new Scene(root);
			scene.setOnKeyPressed(event->keys.put(event.getCode(), true));
			scene.setOnKeyReleased(event-> {
				keys.put(event.getCode(), false);
			});
			
			AnimationTimer timer = new AnimationTimer() {
				
				@Override
				public void handle(long now) {
					update();
					bonus();
				}
			};
			timer.start();
			primaryStage.setTitle("Star Wars Game");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
