package work;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Controller {

	@FXML
	private Button setBtn;
	@FXML
	private Button loginBtn;
	@FXML
	private Button joinBtn;
	@FXML
	private Button mainBtn;
	
	public void setBtn() {
		try {
			Parent login = FXMLLoader.load(getClass().getResource("/work/SettingScene.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) setBtn.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void loginBtn() {
		try {
			Parent login = FXMLLoader.load(getClass().getResource("/work/LoginScene.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) loginBtn.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void mainBtn() {
		try {
			Parent login = FXMLLoader.load(getClass().getResource("/work/MainScene.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) mainBtn.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
